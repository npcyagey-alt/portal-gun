# Portal Gun (Fabric 1.21.1)

Port of "Portal Gun Add-On 1.0" (Bedrock, by JhonFX) to Minecraft Java / Fabric.
Textures, sounds and block models come from the original add-on.

## Build
1. Install JDK 21.
2. In this folder run once:   gradle wrapper --gradle-version 8.10.2     (or open the folder in IntelliJ IDEA as a Gradle project)
3. Run:   ./gradlew build        (Windows: gradlew.bat build)
4. The mod jar is in build/libs/portalgun-1.0.0.jar  (not the -sources one). Put it in .minecraft/mods together with Fabric API 0.105.0+1.21.1.

## How it plays
* Craft: chip, beaker, empty tube, dark matter dust, phase matter, gun bases (see recipes in the creative tab / recipe book).
* Solutions: beaker + amethyst shard -> quantum isotope; + phase matter -> interspatial; + ender eye -> interdimensional; + raw gold -> extradimensional. Place the solution on the ground.
* Right-click a placed solution with an empty tube -> charged tube (3 uses, then an empty beaker remains).
* Gun = gun base + charged tube (crafting table). Green fluid: standard / prototype / prime; blue: blue prototype; yellow: Evil Morty.
* Right-click = shoot a portal (costs 2% charge). Sneak + right-click = change mode (FIFO / LIFO / MULTI_PAIR).
* Refuel: hold the gun in one hand and a matching charged tube in the other, right-click (gun must be at 20% or less). An empty tube is returned when the gun runs dry.
