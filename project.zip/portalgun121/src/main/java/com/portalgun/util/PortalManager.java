package com.portalgun.util;

import com.portalgun.FluidType;
import com.portalgun.ModEntities;
import com.portalgun.ModSounds;
import com.portalgun.entity.FluidProjectileEntity;
import com.portalgun.entity.PortalEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.*;

public class PortalManager {
    private static final int MAX_MULTI = 10;
    /** gun id -> portal entity ids, oldest first */
    private static final Map<UUID, List<UUID>> BY_GUN = new HashMap<>();
    /** entity id -> world time until which it cannot use a portal again */
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    // ---------------------------------------------------------------- lookup
    public static PortalEntity find(ServerWorld any, UUID id) {
        for (ServerWorld w : any.getServer().getWorlds()) {
            Entity e = w.getEntity(id);
            if (e instanceof PortalEntity p && !p.isRemoved()) return p;
        }
        return null;
    }

    public static void register(PortalEntity p) {
        if (p.gunId == null) return;
        List<UUID> l = BY_GUN.computeIfAbsent(p.gunId, k -> new ArrayList<>());
        if (!l.contains(p.getUuid())) l.add(p.getUuid());
    }

    public static void unregister(PortalEntity p) {
        if (p.gunId == null) return;
        List<UUID> l = BY_GUN.get(p.gunId);
        if (l != null) l.remove(p.getUuid());
    }

    // ---------------------------------------------------------------- spawning
    public static void spawnPortal(ServerWorld world, BlockPos hitBlock, Direction side, FluidType fluid, UUID gunId, String mode) {
        PortalEntity p = new PortalEntity(ModEntities.PORTAL, world);
        double x = hitBlock.getX() + 0.5 + side.getOffsetX() * 0.51;
        double z = hitBlock.getZ() + 0.5 + side.getOffsetZ() * 0.51;
        double y;
        if (side.getAxis().isHorizontal()) {
            y = hitBlock.getY();                    // portal stands on the clicked block's level
        } else {
            y = hitBlock.getY() + 0.5 + side.getOffsetY() * 0.51; // plane on the floor / ceiling
        }
        p.setFluid(fluid);
        p.setPortalFacing(side);
        p.gunId = gunId;
        p.refreshPositionAndAngles(x, y, z, 0, 0);
        p.markRegistered();
        world.spawnEntity(p);
        world.playSound(null, p.getBlockPos(), ModSounds.PORTAL_SPAWN, SoundCategory.BLOCKS, 1f, 1f);

        List<UUID> list = BY_GUN.computeIfAbsent(gunId, k -> new ArrayList<>());
        list.add(p.getUuid());

        switch (mode) {
            case "LIFO" -> {
                if (list.size() > 2) removeById(world, list.remove(1));
                if (list.size() == 2) link(world, list.get(0), list.get(1));
            }
            case "MULTI_PAIR" -> {
                if (list.size() > MAX_MULTI) {
                    UUID keep = list.get(list.size() - 1);
                    for (UUID id : new ArrayList<>(list)) if (!id.equals(keep)) removeById(world, id);
                    list.clear();
                    list.add(keep);
                } else if (list.size() % 2 == 0) {
                    link(world, list.get(list.size() - 2), list.get(list.size() - 1));
                }
            }
            default -> { // FIFO
                if (list.size() > 2) removeById(world, list.remove(0));
                if (list.size() == 2) link(world, list.get(0), list.get(1));
            }
        }
    }

    private static void removeById(ServerWorld w, UUID id) {
        PortalEntity e = find(w, id);
        if (e != null) {
            e.getWorld().playSound(null, e.getBlockPos(), ModSounds.PORTAL_CLOSE, SoundCategory.BLOCKS, 1f, 1f);
            e.discard();
        }
    }

    private static void link(ServerWorld w, UUID a, UUID b) {
        PortalEntity pa = find(w, a), pb = find(w, b);
        if (pa == null || pb == null) return;
        // interspatial (blue) portals only connect inside one dimension
        if (!pa.getFluid().crossDimension && pa.getWorld() != pb.getWorld()) return;
        pa.partner = pb.getUuid();
        pb.partner = pa.getUuid();
    }

    // ---------------------------------------------------------------- teleporting
    public static void tickPortal(PortalEntity in) {
        if (in.partner == null || !(in.getWorld() instanceof ServerWorld sw)) return;
        PortalEntity out = find(sw, in.partner);
        if (out == null) return;
        long now = sw.getTime();
        Box box = in.getBoundingBox();
        for (Entity e : sw.getOtherEntities(in, box, x -> !(x instanceof PortalEntity) && !(x instanceof FluidProjectileEntity) && !x.isRemoved())) {
            Long until = COOLDOWN.get(e.getUuid());
            if (until != null && until > now) continue;
            teleport(e, in, out, now);
        }
        if (now % 200 == 0) COOLDOWN.values().removeIf(t -> t < now);
    }

    private static void teleport(Entity e, PortalEntity in, PortalEntity out, long now) {
        boolean sameWorld = in.getWorld() == out.getWorld();
        if (!sameWorld && !(e instanceof ServerPlayerEntity)) return;

        Direction nIn = in.getPortalFacing(), nOut = out.getPortalFacing();
        Vec3d v = e.getVelocity();
        double speed = Math.min(Math.max(v.length(), 0.3), 3.0);

        double nx = out.getX(), ny, nz = out.getZ();
        float yaw = e.getYaw();
        if (nOut.getAxis().isHorizontal()) {
            nx += nOut.getOffsetX() * 0.7;
            nz += nOut.getOffsetZ() * 0.7;
            double dy = nIn.getAxis().isHorizontal() ? MathHelper.clamp(e.getY() - in.getY(), 0, 0.3) : 0;
            ny = out.getY() + dy;
            if (nIn.getAxis().isHorizontal()) {
                yaw += nOut.asRotation() - (nIn.asRotation() + 180f);
            }
        } else if (nOut == Direction.UP) {
            ny = out.getY() + 0.1;
        } else {
            ny = out.getY() - e.getHeight() - 0.1;
        }
        Vec3d vel = new Vec3d(nOut.getOffsetX(), nOut.getOffsetY(), nOut.getOffsetZ()).multiply(speed);
        yaw = MathHelper.wrapDegrees(yaw);

        long until = now + 20;
        COOLDOWN.put(e.getUuid(), until);

        if (e instanceof ServerPlayerEntity sp) {
            ServerWorld target = (ServerWorld) out.getWorld();
            sp.teleport(target, nx, ny, nz, yaw, sp.getPitch());
            sp.setVelocity(vel);
            sp.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(sp));
            sp.fallDistance = 0;
        } else {
            e.refreshPositionAndAngles(nx, ny, nz, yaw, e.getPitch());
            e.setVelocity(vel);
            e.velocityModified = true;
            e.fallDistance = 0;
        }
        out.getWorld().playSound(null, BlockPos.ofFloored(nx, ny, nz), ModSounds.PORTAL_ENTER, SoundCategory.PLAYERS, 1f, 1f);
    }
}
