package com.portalgun;

import net.fabricmc.api.ModInitializer;

public class PortalGunMod implements ModInitializer {
    public static final String MOD_ID = "portalgun";

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
    }
}
