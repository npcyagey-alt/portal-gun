package com.portalgun.item;

import com.portalgun.FluidType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** A tube charged with portal fluid. Hold a portal gun in the other hand and right-click to plug it in. */
public class PortalFluidItem extends Item {
    public final FluidType fluid;

    public PortalFluidItem(Settings settings, FluidType fluid) {
        super(settings);
        this.fluid = fluid;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack self = user.getStackInHand(hand);
        Hand other = hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND;
        ItemStack gun = user.getStackInHand(other);
        if (gun.getItem() instanceof PortalGunItem) {
            return PortalGunItem.tryPlug(world, user, gun, self, hand);
        }
        if (!world.isClient) {
            user.sendMessage(net.minecraft.text.Text.translatable("message.portalgun.empty_tube_hint"), true);
        }
        return TypedActionResult.pass(self);
    }
}
