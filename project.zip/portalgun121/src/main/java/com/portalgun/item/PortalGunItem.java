package com.portalgun.item;

import com.portalgun.FluidType;
import com.portalgun.ModItems;
import com.portalgun.ModSounds;
import com.portalgun.entity.FluidProjectileEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public class PortalGunItem extends Item {
    public static final String CHARGE = "Charge";
    public static final String MODE = "Mode";
    public static final String GUN_ID = "GunId";
    public static final String[] MODES = {"FIFO", "LIFO", "MULTI_PAIR"};
    public static final int COST = 2;

    public final FluidType fluid;

    public PortalGunItem(Settings settings, FluidType fluid) {
        super(settings);
        this.fluid = fluid;
    }

    /** A gun / tube with no stored charge counts as full (100). */
    private static NbtCompound read(ItemStack s) {
        return s.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt();
    }

    private static void write(ItemStack s, NbtCompound n) {
        s.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
    }

    public static int getCharge(ItemStack s) {
        NbtCompound n = read(s);
        return n.contains(CHARGE) ? n.getInt(CHARGE) : 100;
    }

    public static void setCharge(ItemStack s, int charge) {
        NbtCompound n = read(s);
        n.putInt(CHARGE, charge);
        write(s, n);
    }

    public static String getMode(ItemStack s) {
        NbtCompound n = read(s);
        return n.contains(MODE) ? n.getString(MODE) : MODES[0];
    }

    public static void setMode(ItemStack s, String mode) {
        NbtCompound n = read(s);
        n.putString(MODE, mode);
        write(s, n);
    }

    public static UUID getOrCreateId(ItemStack s) {
        NbtCompound n = read(s);
        if (!n.containsUuid(GUN_ID)) {
            n.putUuid(GUN_ID, UUID.randomUUID());
            write(s, n);
        }
        return n.getUuid(GUN_ID);
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return getCharge(stack) < 100;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13f * getCharge(stack) / 100f);
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return fluid.color;
    }

    @Override
    public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.portalgun.charge", getCharge(stack)).formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.portalgun.mode", getMode(stack)).formatted(Formatting.DARK_AQUA));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack gun = user.getStackInHand(hand);

        // tube in the other hand -> plug it in instead of firing
        Hand other = hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND;
        ItemStack otherStack = user.getStackInHand(other);
        if (otherStack.getItem() instanceof PortalFluidItem) {
            return tryPlug(world, user, gun, otherStack, other);
        }

        // sneak -> cycle portal mode
        if (user.isSneaking()) {
            if (!world.isClient) {
                String cur = getMode(gun);
                int i = 0;
                for (int k = 0; k < MODES.length; k++) if (MODES[k].equals(cur)) i = k;
                String next = MODES[(i + 1) % MODES.length];
                setMode(gun, next);
                user.sendMessage(Text.translatable("message.portalgun.mode", next), true);
            }
            return TypedActionResult.success(gun, world.isClient);
        }

        int charge = getCharge(gun);
        if (charge <= 0) {
            if (!world.isClient) world.playSound(null, user.getBlockPos(), ModSounds.EMPTY, SoundCategory.PLAYERS, 1f, 1f);
            return TypedActionResult.fail(gun);
        }

        if (!world.isClient) {
            UUID id = getOrCreateId(gun);
            FluidProjectileEntity p = new FluidProjectileEntity(world, user, fluid, id, getMode(gun));
            p.setItem(new ItemStack(ModItems.tubeFor(fluid)));
            p.setVelocity(user, user.getPitch(), user.getYaw(), 0f, 3.5f, 0f);
            world.spawnEntity(p);
            world.playSound(null, user.getBlockPos(), ModSounds.FIRE, SoundCategory.PLAYERS, 1f, 1f);

            charge = Math.max(0, charge - COST);
            setCharge(gun, charge);
            if (charge == 0) {
                world.playSound(null, user.getBlockPos(), ModSounds.POWER_OFF, SoundCategory.PLAYERS, 1f, 1f);
                user.getInventory().offerOrDrop(new ItemStack(ModItems.EMPTY_TUBE));
            }
        }
        user.getItemCooldownManager().set(this, 4);
        return TypedActionResult.success(gun, world.isClient);
    }

    public static TypedActionResult<ItemStack> tryPlug(World world, PlayerEntity user, ItemStack gunStack, ItemStack tube, Hand tubeHand) {
        PortalGunItem gun = (PortalGunItem) gunStack.getItem();
        PortalFluidItem tubeItem = (PortalFluidItem) tube.getItem();
        if (gun.fluid != tubeItem.fluid) {
            if (!world.isClient) {
                user.sendMessage(Text.translatable("message.portalgun.wrong_fluid"), true);
                world.playSound(null, user.getBlockPos(), ModSounds.ERROR, SoundCategory.PLAYERS, 1f, 1f);
            }
            return TypedActionResult.fail(tube);
        }
        if (getCharge(gunStack) > 20) {
            if (!world.isClient) {
                user.sendMessage(Text.translatable("message.portalgun.too_charged"), true);
                world.playSound(null, user.getBlockPos(), ModSounds.ERROR, SoundCategory.PLAYERS, 1f, 1f);
            }
            return TypedActionResult.fail(tube);
        }
        if (!world.isClient) {
            setCharge(gunStack, getCharge(tube));
            if (!user.getAbilities().creativeMode) tube.decrement(1);
            world.playSound(null, user.getBlockPos(), ModSounds.PLUG, SoundCategory.PLAYERS, 1f, 1f);
            user.sendMessage(Text.translatable("message.portalgun.plugged"), true);
        }
        return TypedActionResult.success(tube, world.isClient);
    }
}
