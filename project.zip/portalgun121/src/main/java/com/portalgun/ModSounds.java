package com.portalgun;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent FIRE = reg("fire_portal_gun");
    public static final SoundEvent EMPTY = reg("empty_portal_gun");
    public static final SoundEvent PORTAL_SPAWN = reg("portal_spawn");
    public static final SoundEvent PORTAL_ENTER = reg("portal_enter");
    public static final SoundEvent PORTAL_CLOSE = reg("close_portal");
    public static final SoundEvent PLUG = reg("portal_gun_plug");
    public static final SoundEvent POWER_OFF = reg("power_off_portal_gun");
    public static final SoundEvent ERROR = reg("portal_gun_error");
    public static final SoundEvent FLUID_BURN = reg("fluid_burn");

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.of("portalgun", name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {}
}
