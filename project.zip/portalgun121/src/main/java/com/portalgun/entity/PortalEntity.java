package com.portalgun.entity;

import com.portalgun.FluidType;
import com.portalgun.util.PortalManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.UUID;

/** One end of a portal pair. Sits on the face of a block ("facing" = the direction it looks out of the wall). */
public class PortalEntity extends Entity {
    private static final TrackedData<Integer> FLUID = DataTracker.registerData(PortalEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> FACING = DataTracker.registerData(PortalEntity.class, TrackedDataHandlerRegistry.INTEGER);

    public UUID partner;
    public UUID gunId;
    private boolean registered;
    private Direction facing; // intentionally not initialised: setPosition() is called from the super constructor

    public PortalEntity(EntityType<? extends PortalEntity> type, World world) {
        super(type, world);
        this.noClip = true;
        this.facing = Direction.SOUTH;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(FLUID, 1);
        builder.add(FACING, Direction.SOUTH.getId());
    }

    public FluidType getFluid() {
        return FluidType.byOrdinal(dataTracker.get(FLUID));
    }

    public void setFluid(FluidType t) {
        dataTracker.set(FLUID, t.ordinal());
    }

    public Direction getPortalFacing() {
        return facing == null ? Direction.SOUTH : facing;
    }

    public void setPortalFacing(Direction d) {
        this.facing = d;
        dataTracker.set(FACING, d.getId());
        updateBox();
    }

    public boolean isHorizontalFacing() {
        return getPortalFacing().getAxis().isHorizontal();
    }

    /** Visual size (width, height) in blocks. */
    public float visualWidth() { return isHorizontalFacing() ? 1.5f : 1.7f; }
    public float visualHeight() { return isHorizontalFacing() ? 2.1f : 1.7f; }

    private Box computeBox(double x, double y, double z) {
        Direction f = getPortalFacing();
        if (f.getAxis().isHorizontal()) {
            double hw = 0.6, hd = 0.1;
            boolean alongX = f.getAxis() == Direction.Axis.Z; // wall normal is Z -> portal is wide along X
            double hx = alongX ? hw : hd;
            double hz = alongX ? hd : hw;
            return new Box(x - hx, y, z - hz, x + hx, y + 2.0, z + hz);
        }
        return new Box(x - 0.8, y - 0.1, z - 0.8, x + 0.8, y + 0.1, z + 0.8);
    }

    private void updateBox() {
        setBoundingBox(computeBox(getX(), getY(), getZ()));
    }

    @Override
    public void setPosition(double x, double y, double z) {
        super.setPosition(x, y, z);
        if (facing != null) setBoundingBox(computeBox(x, y, z));
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (FACING.equals(data)) {
            this.facing = Direction.byId(dataTracker.get(FACING));
            updateBox();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (!registered) {
            registered = true;
            PortalManager.register(this);
        }
        PortalManager.tickPortal(this);
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!getWorld().isClient) PortalManager.unregister(this);
        super.remove(reason);
    }

    public void markRegistered() { registered = true; }

    @Override
    public boolean isCollidable() { return false; }

    @Override
    public boolean canHit() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        if (nbt.containsUuid("Partner")) partner = nbt.getUuid("Partner");
        if (nbt.containsUuid("Gun")) gunId = nbt.getUuid("Gun");
        setFluid(FluidType.byOrdinal(nbt.getInt("Fluid")));
        setPortalFacing(Direction.byId(nbt.getInt("Facing")));
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        if (partner != null) nbt.putUuid("Partner", partner);
        if (gunId != null) nbt.putUuid("Gun", gunId);
        nbt.putInt("Fluid", getFluid().ordinal());
        nbt.putInt("Facing", getPortalFacing().getId());
    }

}
