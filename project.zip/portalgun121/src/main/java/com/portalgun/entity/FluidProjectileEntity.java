package com.portalgun.entity;

import com.portalgun.FluidType;
import com.portalgun.ModEntities;
import com.portalgun.ModItems;
import com.portalgun.ModSounds;
import com.portalgun.item.PortalFluidItem;
import com.portalgun.util.PortalManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

import java.util.UUID;

public class FluidProjectileEntity extends ThrownItemEntity {
    private FluidType fluid = FluidType.GREEN;
    private UUID gunId = new UUID(0, 0);
    private String mode = "FIFO";

    public FluidProjectileEntity(EntityType<? extends FluidProjectileEntity> type, World world) {
        super(type, world);
    }

    public FluidProjectileEntity(World world, LivingEntity owner, FluidType fluid, UUID gunId, String mode) {
        super(ModEntities.FLUID_PROJECTILE, owner, world);
        this.fluid = fluid;
        this.gunId = gunId;
        this.mode = mode;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.GREEN_TUBE;
    }

    @Override
    protected double getGravity() {
        return 0.0;
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient && age > 100) discard();
    }

    @Override
    protected void onBlockHit(BlockHitResult hit) {
        super.onBlockHit(hit);
        if (getWorld() instanceof ServerWorld sw) {
            PortalManager.spawnPortal(sw, hit.getBlockPos(), hit.getSide(), fluid, gunId, mode);
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        super.onEntityHit(hit);
        Entity target = hit.getEntity();
        if (getWorld() instanceof ServerWorld sw && target instanceof LivingEntity le && target != getOwner()) {
            le.damage(sw.getDamageSources().magic(), 2.0f);
            sw.playSound(null, le.getBlockPos(), ModSounds.FLUID_BURN, SoundCategory.PLAYERS, 1f, 1f);
        }
    }

    @Override
    protected void onCollision(HitResult hit) {
        super.onCollision(hit);
        if (!getWorld().isClient) discard();
    }
}
