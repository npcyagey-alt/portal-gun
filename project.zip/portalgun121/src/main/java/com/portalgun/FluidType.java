package com.portalgun;

import net.minecraft.util.Identifier;

public enum FluidType {
    BLUE("blue", 0x3DA5FF, false),     // interspatial: same dimension only
    GREEN("green", 0x57E36B, true),    // interdimensional
    YELLOW("yellow", 0xF5D93A, true);  // extradimensional

    public final String id;
    public final int color;
    public final boolean crossDimension;
    public final Identifier portalTexture;

    FluidType(String id, int color, boolean crossDimension) {
        this.id = id;
        this.color = color;
        this.crossDimension = crossDimension;
        this.portalTexture = Identifier.of("portalgun", "textures/entity/" + id + "_portal.png");
    }

    public static FluidType byOrdinal(int i) {
        FluidType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
