package com.portalgun.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.portalgun.FluidType;
import com.portalgun.ModBlocks;
import com.portalgun.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

import java.util.List;

/** A beaker full of travel solution. LEVEL 3 = full, 2 = mid, 1 = low. Right-click with an empty tube to fill it. */
public class SolutionBlock extends Block {
    public static final IntProperty LEVEL = IntProperty.of("level", 1, 3);
    public static final MapCodec<SolutionBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            createSettingsCodec(),
            Codec.STRING.fieldOf("fluid").forGetter(b -> b.fluid.name())
    ).apply(i, (settings, f) -> new SolutionBlock(settings, FluidType.valueOf(f))));

    public final FluidType fluid;

    public SolutionBlock(Settings settings, FluidType fluid) {
        super(settings);
        this.fluid = fluid;
        setDefaultState(getStateManager().getDefaultState().with(LEVEL, 3));
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return BeakerBlock.SHAPE;
    }

    @Override
    public boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        BlockState below = world.getBlockState(pos.down());
        if (below.getBlock() instanceof BeakerBlock || below.getBlock() instanceof SolutionBlock) return false;
        return Block.sideCoversSmallSquare(world, pos.down(), Direction.UP);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState state, Direction dir, BlockState neighbor,
                                                WorldAccess world, BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN && !canPlaceAt(state, world, pos)) return Blocks.AIR.getDefaultState();
        return super.getStateForNeighborUpdate(state, dir, neighbor, world, pos, neighborPos);
    }

    @Override
    protected ItemActionResult onUseWithItem(ItemStack held, BlockState state, World world, BlockPos pos,
                                             PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!held.isOf(ModItems.EMPTY_TUBE)) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
        if (!world.isClient) {
            int level = state.get(LEVEL);
            world.setBlockState(pos, level > 1 ? state.with(LEVEL, level - 1) : ModBlocks.BEAKER.getDefaultState());
            world.playSound(null, pos, SoundEvents.BLOCK_BREWING_STAND_BREW, SoundCategory.BLOCKS, 1f, 1f);
            if (!player.getAbilities().creativeMode) held.decrement(1);
            player.getInventory().offerOrDrop(new ItemStack(ModItems.tubeFor(fluid)));
        }
        return ItemActionResult.success(world.isClient);
    }

    @Override
    protected List<ItemStack> getDroppedStacks(BlockState state, LootContextParameterSet.Builder builder) {
        if (state.get(LEVEL) == 3) return List.of(new ItemStack(this));
        return List.of(new ItemStack(ModItems.BEAKER));
    }
}
