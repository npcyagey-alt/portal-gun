package com.portalgun;

import com.portalgun.block.BeakerBlock;
import com.portalgun.block.SolutionBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block BEAKER = reg("beaker", new BeakerBlock(settings()));
    public static final Block INTERSPATIAL = reg("interspatial_solution", new SolutionBlock(settings(), FluidType.BLUE));
    public static final Block INTERDIMENSIONAL = reg("interdimensional_solution", new SolutionBlock(settings(), FluidType.GREEN));
    public static final Block EXTRADIMENSIONAL = reg("extradimensional_solution", new SolutionBlock(settings(), FluidType.YELLOW));

    private static AbstractBlock.Settings settings() {
        return AbstractBlock.Settings.create()
                .strength(0f)
                .nonOpaque()
                .sounds(BlockSoundGroup.GLASS)
                .luminance(s -> 4)
                .pistonBehavior(PistonBehavior.DESTROY);
    }

    private static Block reg(String name, Block b) {
        return Registry.register(Registries.BLOCK, Identifier.of("portalgun", name), b);
    }

    public static void init() {}
}
