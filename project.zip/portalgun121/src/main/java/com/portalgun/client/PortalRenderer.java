package com.portalgun.client;

import com.portalgun.entity.PortalEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

public class PortalRenderer extends EntityRenderer<PortalEntity> {
    private static final int FRAMES = 75; // texture is 200 x 15000: 75 square frames

    public PortalRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override
    public Identifier getTexture(PortalEntity e) {
        return e.getFluid().portalTexture;
    }

    @Override
    public void render(PortalEntity e, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light) {
        Direction f = e.getPortalFacing();
        float grow = Math.min(1f, (e.age + tickDelta) / 8f);
        float w = e.visualWidth() / 2f * grow;
        float h = e.visualHeight() / 2f * grow;

        m.push();
        switch (f) {
            case UP -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90));
            case DOWN -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90));
            default -> {
                m.translate(0, 1.0, 0);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-f.asRotation()));
            }
        }

        int frame = (int) ((e.age + tickDelta) * 0.75f) % FRAMES;
        float v0 = frame / (float) FRAMES;
        float v1 = (frame + 1) / (float) FRAMES;

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityTranslucent(getTexture(e)));
        MatrixStack.Entry entry = m.peek();
        Matrix4f pm = entry.getPositionMatrix();
        int full = 0xF000F0;
        // front
        vertex(vc, entry, pm, -w, -h, 0.02f, 0, v1, full, 1);
        vertex(vc, entry, pm, w, -h, 0.02f, 1, v1, full, 1);
        vertex(vc, entry, pm, w, h, 0.02f, 1, v0, full, 1);
        vertex(vc, entry, pm, -w, h, 0.02f, 0, v0, full, 1);
        // back (so it is visible from behind too)
        vertex(vc, entry, pm, w, -h, -0.02f, 1, v1, full, -1);
        vertex(vc, entry, pm, -w, -h, -0.02f, 0, v1, full, -1);
        vertex(vc, entry, pm, -w, h, -0.02f, 0, v0, full, -1);
        vertex(vc, entry, pm, w, h, -0.02f, 1, v0, full, -1);
        m.pop();
    }

    private static void vertex(VertexConsumer vc, MatrixStack.Entry entry, Matrix4f pm, float x, float y, float z, float u, float v, int light, float nz) {
        vc.vertex(pm, x, y, z).color(255, 255, 255, 255).texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(entry, 0, 0, nz);
    }
}
