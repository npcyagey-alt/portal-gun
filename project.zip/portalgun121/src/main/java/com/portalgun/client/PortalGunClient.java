package com.portalgun.client;

import com.portalgun.ModBlocks;
import com.portalgun.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class PortalGunClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.PORTAL, PortalRenderer::new);
        EntityRendererRegistry.register(ModEntities.FLUID_PROJECTILE, FlyingItemEntityRenderer::new);
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getTranslucent(),
                ModBlocks.INTERSPATIAL, ModBlocks.INTERDIMENSIONAL, ModBlocks.EXTRADIMENSIONAL);
    }
}
