package com.portalgun;

import com.portalgun.entity.FluidProjectileEntity;
import com.portalgun.entity.PortalEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<PortalEntity> PORTAL = Registry.register(Registries.ENTITY_TYPE,
            Identifier.of("portalgun", "portal"),
            EntityType.Builder.<PortalEntity>create(PortalEntity::new, SpawnGroup.MISC)
                    .dimensions(1.2f, 2.0f)
                    .maxTrackingRange(6).trackingTickInterval(10).makeFireImmune()
                    .build("portal"));

    public static final EntityType<FluidProjectileEntity> FLUID_PROJECTILE = Registry.register(Registries.ENTITY_TYPE,
            Identifier.of("portalgun", "fluid_projectile"),
            EntityType.Builder.<FluidProjectileEntity>create(FluidProjectileEntity::new, SpawnGroup.MISC)
                    .dimensions(0.25f, 0.25f)
                    .maxTrackingRange(4).trackingTickInterval(2)
                    .build("fluid_projectile"));

    public static void init() {}
}
