package com.portalgun;

import com.portalgun.item.PortalFluidItem;
import com.portalgun.item.PortalGunItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    private static final List<Item> ALL = new ArrayList<>();

    public static final Item EMPTY_TUBE = reg("empty_tube", new Item(new Item.Settings()));
    public static final Item BLUE_TUBE = reg("blue_portal_fluid", new PortalFluidItem(new Item.Settings().maxCount(1), FluidType.BLUE));
    public static final Item GREEN_TUBE = reg("green_portal_fluid", new PortalFluidItem(new Item.Settings().maxCount(1), FluidType.GREEN));
    public static final Item YELLOW_TUBE = reg("yellow_portal_fluid", new PortalFluidItem(new Item.Settings().maxCount(1), FluidType.YELLOW));

    public static final Item CHIP = reg("chip", new Item(new Item.Settings()));
    public static final Item DARK_MATTER_DUST = reg("dark_matter_dust", new Item(new Item.Settings()));
    public static final Item PHASE_MATTER = reg("phase_matter", new Item(new Item.Settings()));
    public static final Item QUANTUM_ISOTOPE = reg("quantum_isotope", new Item(new Item.Settings()));

    public static final Item BEAKER = reg("beaker", new BlockItem(ModBlocks.BEAKER, new Item.Settings()));
    public static final Item INTERSPATIAL = reg("interspatial_solution", new BlockItem(ModBlocks.INTERSPATIAL, new Item.Settings().maxCount(16)));
    public static final Item INTERDIMENSIONAL = reg("interdimensional_solution", new BlockItem(ModBlocks.INTERDIMENSIONAL, new Item.Settings().maxCount(16)));
    public static final Item EXTRADIMENSIONAL = reg("extradimensional_solution", new BlockItem(ModBlocks.EXTRADIMENSIONAL, new Item.Settings().maxCount(16)));

    public static final Item STANDARD_BASE = reg("standard_portal_gun_base", new Item(new Item.Settings().maxCount(1)));
    public static final Item PROTOTYPE_BASE = reg("prototype_portal_gun_base", new Item(new Item.Settings().maxCount(1)));
    public static final Item EVIL_MORTY_BASE = reg("evil_morty_portal_gun_base", new Item(new Item.Settings().maxCount(1)));
    public static final Item PRIME_BASE = reg("prime_portal_gun_base", new Item(new Item.Settings().maxCount(1)));

    public static final Item STANDARD_GUN = reg("standard_portal_gun", new PortalGunItem(new Item.Settings().maxCount(1).fireproof(), FluidType.GREEN));
    public static final Item PROTOTYPE_GUN = reg("prototype_portal_gun", new PortalGunItem(new Item.Settings().maxCount(1).fireproof(), FluidType.GREEN));
    public static final Item BLUE_PROTOTYPE_GUN = reg("blue_prototype_portal_gun", new PortalGunItem(new Item.Settings().maxCount(1).fireproof(), FluidType.BLUE));
    public static final Item EVIL_MORTY_GUN = reg("evil_morty_portal_gun", new PortalGunItem(new Item.Settings().maxCount(1).fireproof(), FluidType.YELLOW));
    public static final Item PRIME_GUN = reg("prime_portal_gun", new PortalGunItem(new Item.Settings().maxCount(1).fireproof(), FluidType.GREEN));

    private static Item reg(String name, Item item) {
        ALL.add(item);
        return Registry.register(Registries.ITEM, Identifier.of("portalgun", name), item);
    }

    public static Item tubeFor(FluidType t) {
        return switch (t) {
            case BLUE -> BLUE_TUBE;
            case GREEN -> GREEN_TUBE;
            case YELLOW -> YELLOW_TUBE;
        };
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(STANDARD_GUN))
                .displayName(Text.translatable("itemGroup.portalgun"))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of("portalgun", "main"), group);
    }
}
